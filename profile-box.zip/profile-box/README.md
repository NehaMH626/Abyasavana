# Getting Started with Create React App

Commands : 
npm install
npm start

Runs the app in the development mode.
Open http://localhost:3000 to view it in the browser.

App feature :
- Displays candidates details
- Candidates can be shortlisted, rejected
- Search Candidate by name

