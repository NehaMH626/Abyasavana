import Axios from 'axios';
import {_Profile_API_Response, _Error_Response, _Get_Search_By_Name_Value} from '../constants/type'
import _API_Constants from '../constants/apiConstants'

export const _Profile_API = () => (dispatch) => {
    Axios.get(`${_API_Constants.apiPath._api_profileData}`)
    .then(res => {
        dispatch({
            type : _Profile_API_Response,
            payload: res.data
        })
    }).catch(err => {
        dispatch({
            type : _Error_Response,
            payload: err
        })

    })
}
