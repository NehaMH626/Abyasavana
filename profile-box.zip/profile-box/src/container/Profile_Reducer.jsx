
import {_Profile_API_Response, _Error_Response} from '../constants/type';

const initialState = {
    profileList_response:[],
    errorInfo: [],
    searchByNameVal: ''
}

export default function(state = initialState, action) {
    switch (action.type) {
        case _Profile_API_Response:
            return {
                ...state,
                profileList_response : action.payload,
            };
        case _Error_Response:
            return {
                ...state,
                errorInfo : action.payload,
            };    

        default:
            return state;
    }
};