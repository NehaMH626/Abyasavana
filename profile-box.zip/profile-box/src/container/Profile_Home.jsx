import Header from '../components/Header';
import ProfileBook from '../components/ProfileBook';
import React from "react";
import NavList from '../components/NavList';
import { _Profile_API } from "../container/Profile_Actions";
import { connect } from "react-redux";
import { useState, useEffect } from "react";
import { withRouter } from "react-router-dom";

const ProfileHome = (props) => {
    const [profileList, setProfileList] = useState([]);
    const [searchVal, setSearchVal] = useState('');

    const getSearchVal = (updatedSearchVal) => {
        console.log("updatedSearchVal : ", updatedSearchVal);
        setSearchVal(updatedSearchVal);
    }

    useEffect(() => {
        props._Profile_API();
      }, []);

      useEffect(() => {
        console.log(props);
        props.location.pathname === "/" ? setProfileList(props.profileList_api_response) : setProfileList(props.data);
      },[props]);

    return(
        <div>
            <Header getSearchVal={getSearchVal}/>
            <NavList/>
            <ProfileBook data = {profileList} updatedSearchVal={searchVal}/>
        </div>
    )

}

const mapStateToProps = (store) => {
    return {
      profileList_api_response: store.profileReducer.profileList_response,
    };
  };
  
  const mapDispatchToProps = (dispatch) => ({
    _Profile_API: (payload) => dispatch(_Profile_API(payload)),
  });

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(withRouter(ProfileHome));