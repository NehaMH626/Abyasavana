import "./App.css";
import { Provider } from "react-redux";
import store from "../src/configs/store";
import Profile from "../src/components/Profile";
import ProfileHome from "./container/Profile_Home";
import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

class App extends Component {
  render() {
    return (
     
      <Provider store={store}> 
        <Router>
          <Switch>
            <Route exact path="/"><ProfileHome/></Route>
            <Route exact path="/ID:id"><Profile/></Route>
            <Route exact path="/shortlisted"><ProfileHome data={JSON.parse(localStorage.getItem('shortlistedList'))}/></Route>
            <Route exact path="/rejected"><ProfileHome data={JSON.parse(localStorage.getItem('rejectedList'))}/></Route>
          </Switch>
        </Router>
      </Provider>
    );
  }
}
export default App;
