const API_Constants = {
    apiPath : {
        _api_profileData : 'https://s3-ap-southeast-1.amazonaws.com/he-public-data/users49b8675.json'
    }
}

export default API_Constants;