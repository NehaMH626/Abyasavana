export const _Profile_API_Response = '_Profile_API_Response';
export const _Error_Response = '_Error_Response';
export const _Get_Search_By_Name_Value = '_Get_Search_By_Name_Value'
