import {createStore, applyMiddleware, compose} from 'redux'; 
import thunk from 'redux-thunk';
import {combineReducers} from 'redux';
import {handleActions} from 'redux-actions';
import profileReducer from '../../src/container/Profile_Reducer';
import API_Constants from '../constants/apiConstants';
import literals from '../constants/stringLiterals';

const middleware = [thunk];

var combinedReducers = combineReducers({
    profileReducer : profileReducer,
    ...{stringLiterals: handleActions({}, literals)},
    ...{apiConstants : handleActions({}, API_Constants)}
});

const initialState = {};
const store = createStore(combinedReducers, initialState, compose(applyMiddleware(...middleware)));

export default store;