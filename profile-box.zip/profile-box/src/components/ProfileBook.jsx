import { useState, useEffect } from "react";
import React from "react";
import { Container, Row, Col, Card} from "react-bootstrap";
import '../container/Profile.css';
import {
    BrowserRouter as Router,
    Link,
    generatePath
} from 'react-router-dom';

const ProfileBook = (props) => {
  const [profileList, setProfileList] = useState([]);
  const [id, setId] = useState();
  
  useEffect(() => {
    console.log(props.profileList);

    if (props.data?.length) {
      setProfileList(props.data);
    }

    if (props.updatedSearchVal != '') {
      let searchByName = props.data.filter(searchedObj => searchedObj.name === props.updatedSearchVal);
      console.log("searchByName", searchByName);
      setProfileList(searchByName);
    }
  },[props]);

  const handlePath = (profileID) => {
    setId(profileID);
    localStorage.setItem('currentProfileID', profileID);
    id && this.props.history.push(generatePath("/ID:id", { id }));
  };

  return (
    <div>
      <Container>
      <Row>
      {profileList.length
        ? profileList.map((profile, index) => {
            return (
                <Col xs={6} md={3} lg={2} className="profileCard" key={index}>
                <Link to={`/ID:${profile.id}`} onClick={() => handlePath(profile.id)}>
                  
                    <Card style={{ width: "18rem" }}>
                      <Card.Img variant="top" src={profile.Image} />
                      <Card.Body>
                        <Card.Title>{profile.name}</Card.Title>
                      </Card.Body>
                      <Card.Footer className="text-muted">ID : {profile.id}</Card.Footer>
                    </Card>
                  </Link>
                  </Col>
            );
          })
        : <div><h6 className="positionCenter">No Profiles to be displayed</h6></div>}
        </Row>
        </Container>
    </div>
  );
};

export default ProfileBook;
