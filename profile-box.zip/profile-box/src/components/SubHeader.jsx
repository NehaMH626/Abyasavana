import React from "react";
import { Row, Col } from "react-bootstrap";
import "../container/Profile.css";
import { withRouter } from "react-router-dom";

const SubHeader = (props) => {

  const backToHome = () => {
    props.history.push('/');
  };

  return (
    <div>
      <Row className="appHeader">
        <Col xs={10} md={10} lg={10}>
          <h1 className="appName">
            Profile Box <i className="fa fa-dropbox" />
          </h1>
        </Col>
        <Col xs={2} md={2} lg={2}>
          <div className="input-group mb-3">
            <button
              className="btn btn-outline-secondary"
              type="button"
              id="backToHome"
              onClick={backToHome}
            >
              <i className="fa fa-home" /> Home
            </button>
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default withRouter(SubHeader);
