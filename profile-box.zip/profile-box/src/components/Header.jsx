import React from "react";
import { useState } from "react";
import {Row, Col} from "react-bootstrap";
import "../container/Profile.css";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";

const Header = (props) => {
  const[searchVal, setSearchVal] = useState('');
  const {getSearchVal} = props;

  const search = (e) => {
    setSearchVal(e.target.value);
    console.log(searchVal);
  };

  return (
    <div>
      <Row className="appHeader"> 
        <Col xs={12} md={7} lg={7}>
          <h1 className="appName">Profile Box <i className='fa fa-dropbox'/></h1>
        </Col>
        <Col xs={12} md={5} lg={5}>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by name"
            aria-label="Search"
            aria-describedby="button-addon2"
            onChange={e => search(e)}
          />
          <button
            className="btn btn-outline-secondary"
            type="button"
            id="button-addon2"
            onClick={() => props.getSearchVal(searchVal)}
          >
            <i className="fa fa-search"/>
          </button>
        </div>
        </Col>
      </Row>
    </div>
  );
};

export default Header;
