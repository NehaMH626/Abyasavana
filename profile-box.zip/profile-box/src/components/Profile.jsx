import { useState, useEffect } from "react";
import React from "react";
import {
  Row,
  Col,
  Card,
  Button,
} from "react-bootstrap";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import SubHeader from "./SubHeader";


const Profile = (props) => {
  const [profileData, setProfileData] = useState([]);
  const [currentProfileID, setCurrentProfileID] = useState([]);
  const [profileList, setProfileList] = useState([]);
  const [shortlistedArr, setShortlisted] = useState(localStorage.getItem('shortlistedList'));
  const [rejectedArr, setRejected] = useState(localStorage.getItem('rejectedList'));
  
  useEffect(() => {
    setCurrentProfileID(localStorage.getItem("currentProfileID"));
    setProfileList(props.profileList_api_response);
  }, []);

  useEffect(() => {
    console.log(profileList);
    let profileObj = profileList.filter((profileObj) => {
      return profileObj.id === currentProfileID;
    });
    console.log(profileObj);
    setProfileData(profileObj);
    
  }, [profileList]);

  const profileExists = (arr, id) => {
    return arr.some(function(el) {
      return el.id === id;
    }); 
  };

  const shortlistedProfile = (profile) => {

    let shortlisted = localStorage.getItem('shortlistedList') ? JSON.parse(localStorage.getItem('shortlistedList')) : [];
    let shortlistedList =[...shortlisted];

    console.log("profileExist", profileExists(shortlistedList , profile.id));
  
    if(!profileExists(shortlistedList , profile.id)){
      shortlistedList.push(profile);
      console.log('shortlistedList 2', shortlistedList);
    }
    if(rejectedArr != null && profileExists(JSON.parse(rejectedArr), profile.id)){
      let rejectedList = [...JSON.parse(rejectedArr)];
      rejectedList.pop(profile);
      localStorage.setItem('rejectedList', JSON.stringify(rejectedList));
    }

    localStorage.setItem('shortlistedList', JSON.stringify(shortlistedList));
    props.history.push('/');
    console.log(JSON.parse(localStorage.getItem('shortlistedList')));
    console.log('shortlistedList', shortlistedList);
  };

  const rejectedProfile =(profile) => {
    let rejected = localStorage.getItem('rejectedList') ? JSON.parse(localStorage.getItem('rejectedList')) : [];
    let rejectedList = [...rejected];

    console.log("profileExist", profileExists(rejectedList , profile.id));

    if(!profileExists(rejectedList , profile.id)){
      rejectedList.push(profile);
    }

    if(shortlistedArr != null && profileExists(JSON.parse(shortlistedArr), profile.id)){
      let shortlistedList = [...JSON.parse(shortlistedArr)];
      shortlistedList.pop(profile);
      localStorage.setItem('shortlistedList', JSON.stringify(shortlistedList));
    }

    localStorage.setItem('rejectedList', JSON.stringify(rejectedList));
    props.history.push('/');
    console.log('rejectedList', rejectedList);
  };

  return (
    <div>
      <SubHeader />
      {profileData.length
        ? profileData.map((profile, index) => {
            return (
              <Row>
                <Col xs={12} md={8} lg={8}>
                  <Card className="text-center bioCard">
                    <Card.Header></Card.Header>
                    <Card.Body>
                      <Card.Img
                        variant="top"
                        src={profile.Image}
                        className="bioImg"
                      />
                      <Card.Title>Name : {profile.name}</Card.Title>
                      <Card.Text>ID : {profile.id}</Card.Text>
                    </Card.Body>
                    <Card.Footer className="text-muted"></Card.Footer>
                  </Card>
                </Col>
                <Col xs={12} md={4} lg={4}>
                  <Card className="text-center bioCard bioBtnCard">
                    <Button variant="primary" className="btnBottom" onClick={() => shortlistedProfile(profile)}>
                      Shortlisted
                    </Button>
                    <Button variant="primary" onClick={() => rejectedProfile(profile)}>Rejected</Button>
                  </Card>
                </Col>
              </Row>
            );
          })
        : null}
      ;
    </div>
  );
};

const mapStateToProps = (store) => {
  return {
    profileList_api_response: store.profileReducer.profileList_response,
  };
};

const mapDispatchToProps = (dispatch) => ({});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(Profile));
