import React from "react";
import { useState } from "react";
import { Nav } from "react-bootstrap";
import "../container/Profile.css";

const NavList = (props) => {
  const [activeNavItem, setActiveNavItem] = useState(0);

  const navLinks = [
    { id: 1, to: "/", linkName: "Home" },
    { id: 2, to: "/shortlisted", linkName: "Shortlisted" },
    { id: 3, to: "/rejected", linkName: "Rejected" },
  ];

  const onNavItemClick = (index) => {
    console.log("active Index", index);
    setActiveNavItem(index);
  };

  return (
    <Nav
      className="justify-content-end nav"
      variant="tabs"
      defaultActiveKey= "/"
    >
      {navLinks.map((navItem, index) => {
        return (
          <Nav.Item key={index}  onClick={() => onNavItemClick(index)} > 
            <Nav.Link href = {navItem.to} activeClassName="active" >{navItem.linkName}</Nav.Link>
          </Nav.Item>
                  //   <Nav.Item key={index}  onClick={() => onNavItemClick(index)} href={navItem.to} className={activeNavItem === index ? "activeNav" : "inActiveNav"} > 
                  //   <Nav.Link href = {navItem.to} activeClassName="active" className={activeNavItem === index ? "activeNavLink" : "inActiveNavLink"}>{navItem.linkName}</Nav.Link>
                  // </Nav.Item>
        );
      })};

    </Nav>
  );
};
export default NavList;
