import AppHead from "../components/appHead";
import Buildings from "../components/buildings";
import React from 'react';


function HomePage() {

    return(
        <div>
            <AppHead />
            <Buildings />
        </div>
    );
}
export default HomePage;