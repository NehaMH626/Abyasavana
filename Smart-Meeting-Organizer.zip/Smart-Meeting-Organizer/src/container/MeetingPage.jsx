import ScheduleMeeings from "../components/scheduleMeetings";
import AppHead from "../components/appHead";
import React from 'react';

function MeetingPage() {

    return(
        <div>
            <AppHead />
            <ScheduleMeeings />
        </div>
    );
}
export default MeetingPage;