import React from 'react';
function AppHead(){

    return(
        <div>
            <h1>Smart Meeting Organiser</h1>
        </div>
    );
}
export default AppHead;