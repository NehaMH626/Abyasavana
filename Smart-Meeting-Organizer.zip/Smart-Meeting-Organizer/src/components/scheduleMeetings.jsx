import React, { useEffect, useState } from "react";
import DatePicker from "react-date-picker";
import TimePicker from "react-time-picker";
import { InputGroup, Card, Button, Form } from "react-bootstrap";

function ScheduleMeeings() {
  const dateNow = new Date();
  const getTimeNow = `${dateNow.getHours()} : ${dateNow.getMinutes()}`;
  const [date, setDate] = useState(dateNow);
  const [startTime, setStartTime] = useState(getTimeNow);
  const [endTime, setEndTime] = useState(getTimeNow);
  const [selectedBuilding, setSelectedBuilding] = useState([]);
  const [buildingsData, setBuildingsData] = useState([]);
  const [meetingRoomsData, setMeetingRoomsData] = useState([]);
  const [isFreeRoomsAvailabilityShown, setIsFreeRoomsAvailabilityShown] = useState(false);
  const [freeRoomsData, setFreeRoomsData] = useState([]);
  const [freeRoomsAtSelectedBuilding, setfreeRoomsAtSelectedBuilding] = useState([]);

  const handleBuildingSelect = (e) => {
    console.log("selected building : ", e.target.value);
    setSelectedBuilding(e.target.value);

  };

  useEffect(() => {
    if(freeRoomsData.length) {

        let freeRoomsAtSelectedBuildingData = freeRoomsData.filter((freeRoomsAtBuilding) => {
            return freeRoomsAtBuilding["building"]["name"] === selectedBuilding;
        });
        setfreeRoomsAtSelectedBuilding(freeRoomsAtSelectedBuildingData);
    }
  },[selectedBuilding]);

  useEffect(() => {
    setBuildingsData(JSON.parse(localStorage.getItem("buildingsData")));
    setMeetingRoomsData(JSON.parse(localStorage.getItem("meetingRoomsData")));
    setFreeRoomsData(JSON.parse(localStorage.getItem("freeRoomsData")));
  }, []);

  const handleTimeChange = (type, e) => {
    type(e);
  };

  let inputTimeDisplayData = [
    {
      inputGroupText: " Start Time ",
      onChange: setStartTime,
      value: startTime,
    },
    {
      inputGroupText: " End Time",
      onChange: setEndTime,
      value: endTime,
    },
  ];

  const handleMeetingSchedule = () => {
    setIsFreeRoomsAvailabilityShown(true);
  };

  return (
    <div>
      <h2>Add Meeting</h2>
      <Card>
        <InputGroup className="mb-3">
          <InputGroup.Text id="basic-addon1"> Date</InputGroup.Text>
          <DatePicker onChange={(date) => setDate(date)} value={date} />
        </InputGroup>

        {inputTimeDisplayData.map((inputGroup, index) => {
          return (
            <InputGroup className="mb-3" key={index}>
              <InputGroup.Text id="basic-addon1">
                {" "}
                {inputGroup.inputGroupText}
              </InputGroup.Text>
              <TimePicker
                onChange={(time) => handleTimeChange(inputGroup.onChange, time)}
                value={inputGroup.value}
              />
            </InputGroup>
          );
        })}

        <Form.Select
          aria-label="Default select example"
          onChange={handleBuildingSelect}
        >
          <option>Select Building</option>
          {buildingsData.length ? (
            buildingsData.map((building, index) => (
              <option key={index} value={building.name}>
                {building.name}
              </option>
            ))
          ) : (
            <option value="No meeting rooms">No meeting rooms </option>
          )}
        </Form.Select>

        <Button onClick={() => handleMeetingSchedule()}>Next</Button>
        {isFreeRoomsAvailabilityShown ? 
        <Card>
            <Card.Title>Please select one of the free rooms</Card.Title>
            {freeRoomsAtSelectedBuilding.length ? (freeRoomsAtSelectedBuilding.map((freeRoom, index) => {
                return(
                    <Card>
                        <Card.Title>{freeRoom["name"]}</Card.Title>
                        <Card.Text>Building : {freeRoom["building"]["name"]}</Card.Text>
                        <Card.Text>Floor : {freeRoom["floor"]}</Card.Text>
                    </Card>
                );
            })) : <Card>
                <Card.Text>No free meeeting rooms available</Card.Text>
                </Card>}
            
        </Card> : ""}

        <Button>Save</Button>
      </Card>
    </div>
  );
}
export default ScheduleMeeings;
