import React, { useEffect, useState } from "react";
import axios from "axios";
import constants from "../constants/apiData";
import Card from "react-bootstrap/Card";
import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function Buildings() {
  const [buildingsData, setBuildingsData] = useState([]);
  const [meetingRoomsData, setMeetingRoomsData] = useState([]);
  const [meetingsTodayCount, setMeetingsTodayCount] = useState(0);
  const [freeRoomsData, setFreeRoomsData] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    console.log("fetching buildings data");

    // querying for buildingData
    axios
      .post(constants.endPoint, constants.buildingQuery, constants.headers)
      .then((res) => {
        console.log("buildingQuery data : ", res.data.data["Buildings"]);
        setBuildingsData(res.data.data["Buildings"]);
      });

    // querying for meetingRooms data
    axios
      .post(constants.endPoint, constants.meetingRoomsQuery, constants.headers)
      .then((res) => {
        console.log("meetingRoomsQuery data : ", res.data.data["MeetingRooms"]);
        setMeetingRoomsData(res.data.data["MeetingRooms"]);
      });
  }, []);

  useEffect(() => {
    if (meetingRoomsData.length) {
      // calculate total count of today's meetings
      let totalTodaysMeeting = meetingRoomsData.reduce((totalRooms, room) => {
        totalRooms += room["meetings"].length;
        return totalRooms;
      }, 0);
      setMeetingsTodayCount(totalTodaysMeeting);
      console.log("meetingsTodayCount", meetingsTodayCount);

      // get free room details
      let freeRoomsDetails = meetingRoomsData.filter((room) => {
        return room["meetings"].length === 0;
      });
      setFreeRoomsData(freeRoomsDetails);
      console.log("freeRooms details : ", freeRoomsDetails);

    }
  }, [meetingRoomsData]);

  let displayData = [
    { cardTitle: "Buildings", cardText: [`Total : ${buildingsData.length}`] },
    {
      cardTitle: "Rooms",
      cardText: [
        `Total : ${meetingRoomsData.length}`,
        `Free now : ${freeRoomsData.length}`,
      ],
    },
    {
      cardTitle: "Meetings",
      cardText: [
        `Total ${meetingsTodayCount} today`,
        `Total ${null} going on now`,
      ],
    },
  ];

  const addMeeting = () => {
    console.log("Adding meeting");
    localStorage.setItem("buildingsData", JSON.stringify(buildingsData));
    localStorage.setItem("meetingRoomsData", JSON.stringify(meetingRoomsData));
    localStorage.setItem("freeRoomsData" , JSON.stringify(freeRoomsData));
    navigate("/scheduleMeeings");
  };

  console.log("displayData", displayData);
  return (
    <div>
      <h1>Buildings</h1>   
      {displayData.map((cardData, index) => {
        return (
          <Card key={index}>
            <Card.Body>
              <Card.Title>{cardData["cardTitle"]}</Card.Title>

              {cardData["cardText"].map((cardText, cardTextIndex) => {
                return <Card.Text>{cardText}</Card.Text>;
              })}
            </Card.Body>
          </Card>
        );
      })}
      <Button onClick={() => addMeeting()}>Add a Meeting</Button>
    </div>
  );
}
export default Buildings;
