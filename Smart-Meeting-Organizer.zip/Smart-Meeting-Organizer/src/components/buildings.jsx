import React, { useEffect, useState } from "react";
import axios from "axios";
import constants from "../constants/apiData";
import Card from "react-bootstrap/Card";

function Buildings() {
  const [buildingsData, setBuildingsData] = useState('');
  const [selectedBuilding, setSelectedBuilding] = useState("");

  useEffect(() => {
    console.log("fetching buildings data");

    axios
      .post(constants.endPoint, constants.buildingQuery, constants.headers)
      .then((res) => {
        console.log("buildingQuery data : ", res.data["Buildings"], res.data);
        console.log(Object.keys(res.data));
        setBuildingsData(Object.keys(res.data).length && res.data["Buildings"]);
      });
  }, []);

  let handleBuildingSelect = (e) => {
    console.log("selected building : ", e.target.value);
    setSelectedBuilding(e.target.value);
  };
  console.log("....", buildingsData);
  //console.log("buildingQuery data : ", res.data["Buildings"], res.data);
  return (

    <div>
      <h1>Buildings</h1>   
      <select onChange={handleBuildingSelect}>
        <option value="⬇️ Select building ⬇️"> -- Select Building -- </option>
        {/* {buildingsData && buildingsData.map((building, index) => <option key = {index} value={building.name}>{building.name}</option>)} */}
        {/* {buildingsData["Buildings"].length ? (
          buildingsData.map((building, index) => (
            <option key={index} value={building.name}>
              {building.name}
            </option>
          ))
        ) : (
          <option value="No meeting rooms">No meeting rooms </option>
        )} */}
      </select>
      {/* <Card>
        <Card.Body>
          <Card.Title>Buildings</Card.Title>
          <Card.Text>Total : {buildingsData.length}</Card.Text>
        </Card.Body>
      </Card>
      <Card>
        <Card.Body>
          <Card.Title>Rooms</Card.Title>
          <Card.Text>Total : {buildingsData.length}</Card.Text>
        </Card.Body>
      </Card> */}
    </div>
  );
}
export default Buildings;
