import logo from "./logo.svg";
import "./App.css";
import React from "react";
import HomePage from "./container/homePage";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AppHead from "./components/appHead";
import Buildings from "./components/buildings";
import MeetingPage from "./container/MeetingPage";
import ScheduleMeeings from "./components/scheduleMeetings";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<HomePage />}></Route>
        <Route exact path="/scheduleMeeings" element={<MeetingPage />}></Route>
      </Routes>
    </BrowserRouter>

    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
