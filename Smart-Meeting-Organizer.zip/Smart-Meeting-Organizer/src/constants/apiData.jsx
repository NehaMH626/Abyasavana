const apiConstants = {
    endPoint : "http://smart-meeting.herokuapp.com",
    token : "a123gjhgjsdf6576",
    headers : {
        "content-type": "application/json",
        "Authorization": "a123gjhgjsdf6576"
    },

    buildingQuery : {
        "query": `{ Buildings {name meetingRooms {name meetings { title date startTime endTime } } } }`,
        "variables": {}
    },
    meetingRoomsQuery : {
        "query" : `{
            MeetingRooms{
            name
            floor
            building{
            name
            }
            meetings{
            title
            }
            
            }
            }`,
            "variables": {}
    },
    
    addMeetingQuery : {
        "query" : `mutation {
            Meeting(
            id: 1
            title: "Booked3"
            date: "13/02/2019"
            startTime: "21:00"
            endTime: "22:00"
            meetingRoomId: 1) {
            id
            title
            }
            }`,
            "variables": {}
    }
}

export default apiConstants;